PROPERTY TYCOON — ANDROID APK BUILD PROJECT
============================================

This is an Android app project containing the game locally inside a WebView.
It does not need internet permission and the game runs offline.

FEATURES
- Mobile-friendly property trading game
- Player name entry
- Play against a basic bot
- Dice rolls, properties, rent, taxes, random cards, and money
- No external libraries in the game page

BUILD AN APK WITHOUT A COMPUTER (GitHub Actions)
1. Download and extract this ZIP.
2. Create a new repository on GitHub.
3. Upload all files and folders from this project into the repository root.
4. Open the repository's Actions tab.
5. Select "Build Property Tycoon APK" and tap "Run workflow".
   (A push to the main branch also triggers a build.)
6. When the run finishes, open the workflow run and download the
   "Property-Tycoon-debug-apk" artifact.
7. Extract the artifact ZIP to get app-debug.apk, then open it on Android
   and approve installation if prompted.

IMPORTANT
- This project is designed to build a debug APK using GitHub-hosted runners.
- The APK has a debug signature; it is installable for testing but is not a
  Play Store release.
- This is an original simplified property-trading game, not the official
  Monopoly game and not affiliated with Hasbro.
- No Android SDK is bundled locally in this ZIP; the GitHub workflow installs
  the build dependencies and compiles it remotely.
